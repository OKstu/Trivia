﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trivia
{
    class Program
    {
        static void Main()
        {
            
            string Name;
            string Integer;
            string Class;
            string Object;
            string Double;
            string Void;

            Console.WriteLine("Welcom to the Code of Survival");
            Console.WriteLine("Please Enter Your Name");
            Name = Console.ReadLine();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Welcome " + Name + ". I Hope you're ready, because this is the teast that will decide whether you'll pass and live, or fail and perish. So what are we waiting for? Let's do it!");
            Console.WriteLine("_________________________________________________");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Integer:");
            Integer = Console.ReadLine();
            Console.WriteLine("Class:");
            Class = Console.ReadLine();
            Console.WriteLine("Object:");
            Object = Console.ReadLine();
            Console.WriteLine("Double:");
            Double = Console.ReadLine();
            Console.WriteLine("Void:");
            Void = Console.ReadLine();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Well Done, but make sure you check the score. They will seal your fate.");
            Console.WriteLine("_____________________________________________");
            Console.WriteLine("5 out of 5 = 100%: You pass and can live a long life");
            Console.WriteLine("4 out of 5 = 80%: You pass but 20% of your health was deducted");
            Console.WriteLine("3 out of 5 = 60%: You pass but 40% of your health was deducted");
            Console.WriteLine("2 out of 5 = 40%: You fail and 60% of your health was deducted");
            Console.WriteLine("1 out of 5 = 20%: You fail and 80% of your health was deducted");
            Console.WriteLine("0 out of 5 = 0%: You fail and you will die shortly. See uou in the next 50 years.");
            Console.WriteLine("___________________________________________________");

            

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Credits: This e was made By Mr. O.K., who seems to be having a horrible crises at this moment.");

            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("___________________________________________________");
            Console.WriteLine("There's nothing else available, so, umm........... Just press any key to exit, and farewell...... for now.");

            Console.ReadKey();
        }
    }
}
