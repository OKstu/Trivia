﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Trivia
{
    public class Player
    {
        public string Name;
        public int Score = 0;

        public  Player(string name)
        {
            Name = name;
            Score = 0; 
        }
    }
}