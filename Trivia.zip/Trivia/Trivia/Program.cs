﻿using System;
using static System.Console;

namespace Trivia
{
    class x
    {
        static void Main()
        {
            
            string Integer;
            string Class;
            string Object;
            string Double;
            string Void;

            WriteLine("Welcom to the Code of Survival (Wait, What?");
            WriteLine("Please Enter Your Name");
            Name = ReadLine();

            ForegroundColor = ConsoleColor.Red;
            WriteLine("Welcome " + Name + ". I Hope you're ready, because this is the teast that will decide whether you'll pass and live, or fail and perish. So what are we waiting for? Let's do it!");
            WriteLine("_________________________________________________");

            ForegroundColor = ConsoleColor.Yellow;
            WriteLine("Integer:");
            Integer = ReadLine();
            WriteLine("Class:");
            Class = ReadLine();
            WriteLine("Object:");
            Object = ReadLine();
            WriteLine("Double:");
            Double = ReadLine();
            WriteLine("Void:");
            Void = ReadLine();

            ForegroundColor = ConsoleColor.Blue;
            WriteLine("Well Done, but make sure you check the score. They will seal your fate.");

            WriteLine("_____________________________________________");
            ReadKey();
            WriteLine("5 out of 5 = 100%: You pass and can live a long life");
            ReadKey();
            WriteLine("4 out of 5 = 80%: You pass but 20% of your health was deducted");
            ReadKey();
            WriteLine("3 out of 5 = 60%: You pass but 40% of your health was deducted");
            ReadKey();
            WriteLine("2 out of 5 = 40%: You fail and 60% of your health was deducted");
            ReadKey();
            WriteLine("1 out of 5 = 20%: You fail and 80% of your health was deducted");
            ReadKey();
            WriteLine("0 out of 5 = 0%: You fail and you will die shortly. See uou in the next 50 years.");
            WriteLine("___________________________________________________");

            ReadKey();

            ForegroundColor = ConsoleColor.Green;
            WriteLine("Credits: This was made By Mr. O.K., who seems to be having a horrible crises at this moment.");

            ForegroundColor = ConsoleColor.Gray;
            WriteLine("___________________________________________________");
            WriteLine("There's nothing else available, so, umm........... Just press any key to exit, and farewell...... for now.");

            ReadKey();
        }
    }
}
